import unittest
import pygame


class SurfarrayTest (unittest.TestCase):

    def test_import(self):
        'does it import'
        import pygame.surfarray

    def test_setpixel(self):
        'Can a pixel be set'



    def test_add_more_tests(self):
        'we need to add more tests'
        pass
        #raise NotImplementedError("TODO: surfarray tests need improving.")



if __name__ == '__main__':
    unittest.main()
