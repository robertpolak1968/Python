import unittest
import pygame


class SndarrayTest (unittest.TestCase):

    def test_import(self):
        'does it import'
        import pygame.sndarray



    def test_add_more_tests(self):
        'we need to add more tests'
        pass
        #raise NotImplementedError("TODO: sndarray tests need improving.")



if __name__ == '__main__':
    unittest.main()
