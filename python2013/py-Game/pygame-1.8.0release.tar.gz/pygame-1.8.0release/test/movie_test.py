
import unittest
import pygame, pygame.movie


class MovieTest( unittest.TestCase ):
    
    def test_load_movie( self ):
        """ 
        """


    def test_import(self):
        'does it import'
        import pygame.movie

    def test_add_more_tests(self):
        'we need to add more tests'
        pass
        #raise NotImplementedError("TODO: movie tests need improving.")

if __name__ == '__main__':
    unittest.main()
