"""
__version__ = "$Revision: 1.2 $"
__date__ = "$Date: 2004/05/05 03:51:53 $"
"""

class PythonCardException :

    def __init__( self, aValue ) :
        self._value = aValue

    def __str__(self) :
        return `self._value`

class AbstractMethodException( PythonCardException ) :

    def __init__( self, aValue ) :
        PythonCardException.__init__( self, aValue )

##class EventBindingException( PythonCardException ) :
##
##    def __init__( self, aValue ) :
##        PythonCardException.__init__( self, aValue )
##
##class EventQueueException( PythonCardException ) :
##
##    def __init__( self, aValue ) :
##        PythonCardException.__init__( self, aValue )


class ResourceException( PythonCardException ) :

    def __init__( self, aValue ) :
        PythonCardException.__init__( self, aValue )


##class HandlerException( PythonCardException ) :
##
##    def __init__( self, aValue ) :
##        PythonCardException.__init__( self, aValue )



