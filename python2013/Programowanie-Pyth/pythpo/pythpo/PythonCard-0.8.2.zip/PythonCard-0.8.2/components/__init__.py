"""
Created: 2001/08/05
Purpose: Turn components into a sub-package

__version__ = "$Revision: 1.1 $"
__date__ = "$Date: 2001/12/11 23:47:11 $"

"""
