import pyunit

class ClassTests(pyunit.TestCase):
  def setUp(self):
    pass

  def tearDown(self):
    pass

  def testSomething(self):
    pass
