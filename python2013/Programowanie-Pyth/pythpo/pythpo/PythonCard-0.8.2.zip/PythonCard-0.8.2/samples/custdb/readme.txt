*********** Readme.txt **********************

This is a pythoncard example application.

It makes up a very simple address database. 

Although it uses the german address format it should be fairly 
easy to adapt it to whatever is required.

It is quite useful for keeping track of customer contacts.

It is very very easy to use, so no further explanations here.

It handles several hundred entries without slowing down or any other problem.
It probabely works still fine with some thousand entries, but I did never
test this.

Feel free modify it to whatever use you want.

Have fun

Juergen

email: juergen@yebu.de

Data is stored in a text file in comma separated value (CSV) format. 
For alternative storage formats see the addresses, flatfileDatabase and textIndexer samples.
