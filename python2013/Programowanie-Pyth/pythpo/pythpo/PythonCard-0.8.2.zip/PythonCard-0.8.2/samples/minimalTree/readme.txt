This is a simple test of the Tree component.
