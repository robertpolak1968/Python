helpfulWrappers demonstrates the usage of the wrapper functions in
PythonCard/helpful


