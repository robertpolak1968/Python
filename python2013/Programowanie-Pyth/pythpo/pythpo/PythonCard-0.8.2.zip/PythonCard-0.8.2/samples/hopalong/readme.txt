based on the hopalong algorithm by Barry Martin
presented in the September 1986 Scientific American
Computer Recreations column by A. K. Dewdney
algorithm starts on page 15

some other interesting values to try:
  a = 73, b = 2.6, c = 25
  a = -200, b = .1, c = -80
  a = .4, b = 1, c = 0 (try a scale of 100 or 200 on this one)
  a = -3.14, b = .3, c = .3

I would like to experiment with ways of speeding up the calculation and/or drawing using NumPy. Suggestions are welcome. It would also be nice to be able to save and restore setups and save the current image in the window as a JPEG. I'll explore these options in the future, but you're welcome to make the additions and submit the changes yourself.