moderator, as you may have guessed, is a moderation tool. As someone raises their hand to speak, the moderator clicks their name and it goes on the list of people waiting to speak, in order. When someone is speaking, they have a certain number of minutes to speak. It works best when there's a projector, so everyone can see they're on the list and the speaker can see how much time they have left.

Contributed to the PythonCard community 4/23/2004 by Bruce Eckel
