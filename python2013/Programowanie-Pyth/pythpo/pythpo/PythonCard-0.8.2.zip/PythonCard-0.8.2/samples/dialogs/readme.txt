dialogs shows off all the native dialogs currently supported by PythonCard.
If you need to use a FileDialog, MessageDialog, etc. you should refer to
this sample and copy the code for the dialog you want to use.

dialogs also shows off a minimal user-defined dialog named minimalDialog.py
You can copy minimalDialog.py and minimalDialog.rsrc.py as the basis for your
own custom dialogs.
