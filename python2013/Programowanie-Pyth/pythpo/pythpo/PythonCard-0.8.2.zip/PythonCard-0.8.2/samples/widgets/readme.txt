widgets shows off all the PythonCard widgets. You can set many of the
attributes to see how it impacts each widget type.

The "Create Component Docs..." menu item lets you choose a directory
to save a set of HTML documentation for the PythonCard components. A
"components" directory will be created in the directory
you choose with a file for each component that contains the list of 
attributes and events. You should choose the 
PythonCard/docs/html/framework directory as the save directory if you want
to be able to follow links from the components.html file.
