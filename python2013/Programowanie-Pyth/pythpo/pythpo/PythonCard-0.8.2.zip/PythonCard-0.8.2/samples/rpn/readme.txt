About RPN

Last updated: 2002-12-20

RPN is a Python application written with the PythonCard framework. It is a first attempt to write a complete application using PythonCard, so it may not work (don't use it for your taxes).

Contributed by Randy Lea.
