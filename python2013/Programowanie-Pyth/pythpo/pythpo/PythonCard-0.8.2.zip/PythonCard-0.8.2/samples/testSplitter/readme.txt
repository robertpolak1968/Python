Until we have a Splitter integrated into some of the other samples or tools this will serve as a basic test app, but I don't expect to include it in releases.

There should be variations testing all the splitter varieties we're going to support.

Instead of minimal I was thinking about something more complicated involving the Tree component, List, or MultiColumnList in the left pane.

Perhaps this would also be a good place to test a virtual MultiColumnList, perhaps doing a file list and displaying an image in the top-right pane and EXIF info in the bottom-right or something like that.

Anyway, we need a more complicated example to work through issues about how these things are going to work.

I suppose we could have yet another RSS reader any other ideas?
