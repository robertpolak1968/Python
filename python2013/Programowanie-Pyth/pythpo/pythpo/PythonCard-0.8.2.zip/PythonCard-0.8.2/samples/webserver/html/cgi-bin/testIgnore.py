# ignore is a regular expression that will match the filenames
# for the modules to exclude.
ignore = '.*\.py$'
