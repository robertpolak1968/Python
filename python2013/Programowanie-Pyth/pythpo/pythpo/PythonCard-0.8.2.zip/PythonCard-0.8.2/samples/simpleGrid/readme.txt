This is a work-in-progress sample to test the PythonCard Grid component.

It is a very basic port of the wxPython\demo\GridSimple.py code.

The events are manually bound in the openBackground handler, but will
eventually be wrapped in PythonCard.