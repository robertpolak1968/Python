A simple bitmap drawing test. Select a color using the Color button. Click and drag the mouse to draw on the canvas.

2002-02-28
Added simple Copy and Paste that uses the entire bitmap image.
Added Open and Save As so an image can be imported into the current bitmap and saved to disk in a variety of supported formats: BMP, GIF, JPG/JPEG, PCX, PNG, PNM, TIF/TIFF, XBM, and XPM. Not all formats are supported on every platform and saving as GIF results in a zero length image.

I just started experimenting in order to expand doodle into a more elaborate paint program.
