sounds is a simple test of the sound.py module that can play .wav files.
