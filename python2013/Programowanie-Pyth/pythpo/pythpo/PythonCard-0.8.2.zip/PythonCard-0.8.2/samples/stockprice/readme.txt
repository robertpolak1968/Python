This sample is a clone of the AppleScript Studio example at: 
  http://www.oreillynet.com/pub/a/mac/2002/02/01/applescript_macosx.html

It requires the SOAP.py module from SOAP.py 0.9.7 available at:
  http://sourceforge.net/projects/pywebsvcs

Also see the SOAP.py authors article at:
  http://www-106.ibm.com/developerworks/webservices/library/ws-pyth2/
