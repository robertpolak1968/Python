minimal is almost the smallest PythonCard program possible. Refer to
tutorial.txt for an example of copying and modifying minimal.py as your
first PythonCard program.

See the minimalStandalone sample for information on building standalone
executables and a simple example of a localized resource file in French.