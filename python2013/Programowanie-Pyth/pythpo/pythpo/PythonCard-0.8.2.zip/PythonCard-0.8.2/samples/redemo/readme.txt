redemo.py is a port of the tkinter redemo.py included with Python in the Python22\Tools\Scripts directory.

No additional functionality has been added in the first pass at the port except a menubar with Help items to load useful regular expression documentation in the users browser.
