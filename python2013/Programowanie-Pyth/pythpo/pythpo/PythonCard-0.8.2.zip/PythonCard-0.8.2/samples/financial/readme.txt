I'm not sure whether this will become a real sample or not.

This is a holding place for some demo code I want to build at VanPy.

