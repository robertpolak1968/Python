from wrappers import Turtle

def draw(canvas):
    t = Turtle(canvas)
    t.cls()
