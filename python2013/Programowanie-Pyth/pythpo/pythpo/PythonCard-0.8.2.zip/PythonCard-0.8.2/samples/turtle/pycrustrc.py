from PythonCard.turtle import BitmapTurtle
t = BitmapTurtle(bg.components.bufOff)
t.st()
t.color('blue')
for i in range(5):
    t.fd(50)
    t.lt(72)

