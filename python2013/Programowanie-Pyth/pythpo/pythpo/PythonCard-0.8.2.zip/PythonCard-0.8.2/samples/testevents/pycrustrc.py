import gc
gc.set_debug(gc.DEBUG_LEAK | gc.DEBUG_OBJECTS)
