testevents is used to verify that background and components events fire in
the same order and behave the same on all platforms.
