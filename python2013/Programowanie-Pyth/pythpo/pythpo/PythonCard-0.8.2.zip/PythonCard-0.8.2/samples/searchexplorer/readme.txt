searchExplorer was the first "useful" PythonCard app. It presents a list of
search sites and when the user clicks the "Search" button, it launches a web
browser to display the search results at the given site. It automatically
keeps tracks of the searches made and saves them to disk. searchExplorer has
an Edit menu that you might want to copy for your own code. The textIndexer
and resourceEditor samples uses a similar Edit menu that use 'command'
handlers rather than menu handlers which you might want to use instead.

I use findfiles, searchExplorer, SourceForgeTracker, and worldclock every day,
so I keep a shortcut to each app on my desktop; I renamed the copies with a .pyw
extension so a console doesn't appear when I double-click the shortcuts.
