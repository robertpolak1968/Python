This is a simple test of the MultiColumnList component.
