Conversion of Flash animation to PythonCard.

http://www.bit-101.com/tutorials/gravity.html
