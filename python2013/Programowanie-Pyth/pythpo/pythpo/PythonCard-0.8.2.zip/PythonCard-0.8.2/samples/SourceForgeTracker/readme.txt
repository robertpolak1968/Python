SourceForgeTracker downloads XML from SourceForge in order to display Bug
Reports and Feature Requests for a variety of Python SF projects. The XML
processing of the Unicode is a bit buggy, so not all items are displayed.
SourceForgeTracker provides an example of two alternative layouts, one that
has the standard "gray" dialog look and one that uses an alternative
backgroundColor and empty Image widgets behind the other widgets to give it
a Yahoo-style look.
