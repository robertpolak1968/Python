proof grew out of the original proof of concept for PythonCard. It shows off
all the widgets, but the widgets sample does a much better job of showing
all the widgets and allowing the user to experiment with changing the
widget attributes (properties). proof shows the use of a tiled background
image and handles some events not used in any of the other samples. proof
will probably be replaced in the future by a sample dedicated to testing
all possible events.
