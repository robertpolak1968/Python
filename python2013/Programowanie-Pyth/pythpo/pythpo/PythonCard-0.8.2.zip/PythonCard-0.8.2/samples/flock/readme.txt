Builds on the "gravity" sample to show a simple animation of "boids"; shows simple emergent behaviour for a 2-D flock of "boids".

This sampe uses two images to animate the movement of bird-like objects.
