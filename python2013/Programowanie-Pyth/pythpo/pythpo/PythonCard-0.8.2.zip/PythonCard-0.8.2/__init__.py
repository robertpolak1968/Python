"""
Created: 2001/08/05
Purpose: Turn PythonCard into a package

__version__ = "$Revision: 1.1.1.1 $"
__date__ = "$Date: 2001/08/06 19:53:11 $"

"""
