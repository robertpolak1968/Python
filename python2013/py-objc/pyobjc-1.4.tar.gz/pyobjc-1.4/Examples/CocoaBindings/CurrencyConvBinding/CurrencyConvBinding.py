from PyObjCTools import AppHelper

# import classes required to start application
import Converter
import CurrencyConvBindingDocument

if __name__ == '__main__':
    # start the event loop
    AppHelper.runEventLoop()
