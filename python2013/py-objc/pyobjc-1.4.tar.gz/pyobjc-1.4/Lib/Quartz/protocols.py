# Manually generated
import objc as _objc

PDFViewDelegate = _objc.informal_protocol(
        "PDFViewDelegate",
        [
            _objc.selector(
                None,
                selector='PDFViewWillChangeScaleFactor:toScale:',
                signature='f@:@f',
                isRequired=0,
            ),
        ]
)
