# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
setSignatureForSelector("ScreenSaverUserInfo", "loginUserName:andID:", "v@:o^@o^I")
# end of file
