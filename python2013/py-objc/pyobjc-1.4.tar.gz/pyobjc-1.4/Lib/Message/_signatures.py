# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
setSignatureForSelector('DataScanner', 'scanBytesFromSet:intoData:', 'c@:@o^@')
setSignatureForSelector('DataScanner', 'scanCString:intoData:', 'c@:r*o^@')
setSignatureForSelector('DataScanner', 'scanData:intoData:', 'c@:@o^@')
setSignatureForSelector('DataScanner', 'scanInt:', 'c@:o^i')
setSignatureForSelector('DataScanner', 'scanUpToBytesFromSet:intoData:', 'c@:@o^@')
setSignatureForSelector('DataScanner', 'scanUpToCString:intoData:', 'c@:r*o^@')
setSignatureForSelector('DataScanner', 'scanUpToData:intoData:', 'c@:@o^@')
setSignatureForSelector('Library', 'bodyDataAtPath:headerData:', '@@:@o^@')
setSignatureForSelector('Library', 'bodyDataForMessage:andHeaderDataIfReadilyAvailable:', '@@:@o^@')
setSignatureForSelector('Library', 'fullBodyDataForMessage:andHeaderDataIfReadilyAvailable:', '@@:@o^@')
setSignatureForSelector('Library', 'gatherCountsForMailbox:totalCount:unreadCount:deletedCount:totalSize:', 'v@:@o^Lo^Lo^Lo^Q')
setSignatureForSelector('Message', 'isParentResponseMessage:isRejected:requestedAddresses:requestIsForSenders:', 'c@:o^co^c@o^c')
setSignatureForSelector('MessageStore', 'fullBodyDataForMessage:andHeaderDataIfReadilyAvailable:', '@@:@o^@')
# end of file
