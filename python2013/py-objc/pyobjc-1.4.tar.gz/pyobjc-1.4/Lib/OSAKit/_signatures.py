# This file is generated using the Signatures tool, don't edit
from objc import setSignatureForSelector
setSignatureForSelector('OSAScript', 'compileAndReturnError:', 'c@:o^@')
setSignatureForSelector('OSAScript', 'executeAndReturnDisplayValue:error:', '@@:o^@o^@')
setSignatureForSelector('OSAScript', 'executeAndReturnError:', '@@:o^@')
setSignatureForSelector('OSAScript', 'sourceAndReturnError:', '@@:o^@')
# end of file
