# generated from '/System/Library/Frameworks/Automator.framework'
import objc as _objc


